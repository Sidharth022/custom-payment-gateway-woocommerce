<?php
if (!defined('ABSPATH')) exit;


/* Gate way For Upi Qr Payments */
class WC_Gateway_Custom_UPI extends WC_Payment_Gateway {

    public string $upi_id = '';
    public string $webhook_secret = '';

    public function __construct() {
        $this->id = 'custom_upi';
        $this->method_title = 'UPI QR Payment (Intent)';
        $this->method_description = 'Pay using UPI apps like Google Pay, PhonePe.';
        $this->has_fields = true;

        $this->init_form_fields();
        $this->init_settings();

        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');
        // $this->upi_id = $this->get_option('upi_id');
        $this->webhook_secret = $this->get_option('webhook_secret');
        $this->description = $this->get_option('description');  

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title' => 'Enable/Disable',
                'type' => 'checkbox',
                'label' => 'Enable UPI Payment',
                'default' => 'yes',
            ],
            'title' => [
                'title' => 'Title',
                'type' => 'text',
                'default' => '<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/QR_code_for_mobile_English_Wikipedia.svg/250px-QR_code_for_mobile_English_Wikipedia.svg.png" style="height : 40px"> <span>UPI QR Payment </span>(Google Pay, PhonePe) ',
            ],
            /* 'upi_id' => [
                'title' => 'Your UPI ID',
                'type' => 'text',
                'default' => 'yourupi@bank',
            ], */
            'description' => [
                'title' => 'Description',
                'type' => 'textarea',
                'default' => 'You will be redirected to complete the UPI payment using Google Pay or PhonePe.',
            ],
            'webhook_secret' => [
                'title' => 'Webhook Secret Key',
                'type' => 'text',
                'default' => '9e365899-3a23-4ee1-bd66-6dd2c7178078',
            ]
        ];
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        $webhook_url = home_url('/') . "?wc_upi_webhook=1&secret={$this->webhook_secret}&";

        $payload = [
            "key"               => "{$this->webhook_secret}",
            "client_txn_id"     => (string) $order_id,
            "amount"            => number_format($order->get_total(), 2, '.', ''),
            "p_info"            => "Order #$order_id",
            "customer_name"     => $order->get_formatted_billing_full_name(),
            "customer_email"    => $order->get_billing_email(),
            "customer_mobile"   => substr(preg_replace('/\D/', '', $order->get_billing_phone()), -10),
            "redirect_url"      => $webhook_url,
        ];
       
        $response = wp_remote_post('https://api.ekqr.in/api/create_order', [
            'method'  => 'POST',
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => json_encode($payload),
            'timeout' => 40,
        ]);

        if (is_wp_error($response)) {
            wc_add_notice('Payment error: ' . $response->get_error_message(), 'error');
            return;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!empty($body['data']['payment_url'])) {
            return [
                'result'   => 'success',
                'redirect' => esc_url_raw($body['data']['payment_url'])
            ];
        }

        if ($body['msg'] === "client_txn_id already exists") {
            if ($order->get_status() !== 'cancelled') {
                $order->update_status('cancelled', 'UPI payment failed or not completed.');
                $order->add_order_note('Order auto-cancelled due to UPI failure.');
            }

            wc_add_notice("Payment failed. Please try placing the order again.", 'error');

            return [
                'result'   => 'success',
                'redirect' => wc_get_checkout_url()
            ];
        }

        wc_add_notice("Payment initiation failed: " . ($body['data']['msg'] ?? 'Order Cancelled'), 'error');
        return;
    }
}


/* Gateway for  Upi Payement using mobile apps direct with intent*/

class WC_Gateway_Payment_Intent extends WC_Payment_Gateway {

    public string $upi_id = '';
    public string $webhook_secret = '';

    public function __construct() {
        $this->id = 'mobile_upi_payment';
        $this->method_title = 'UPI Payment (For Mobile Apps Payment)';
        $this->method_description = 'Pay using UPI apps like Google Pay, PhonePe. Direct With Phone';
        $this->has_fields = true;

        $this->init_form_fields();
        $this->init_settings();

        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');
        // $this->upi_id = $this->get_option('upi_id');
        $this->webhook_secret = $this->get_option('webhook_secret');
        $this->description = $this->get_option('description');  

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title' => 'Enable/Disable',
                'type' => 'checkbox',
                'label' => 'Enable UPI Payment',
                'default' => 'no',
            ],
            'title' => [
                'title' => 'Title',
                'type' => 'text',
                'default' => '<img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/batman-returns/logos/UPI.gif" style="height : 40px"> <span>UPI Payment </span>(Using Phone Upi Apps) ',
            ],
            /* 'upi_id' => [
                'title' => 'Your UPI ID',  
                'type' => 'text',
                'default' => 'yourupi@bank',
            ], */
            'description' => [
                'title' => 'Description',
                'type' => 'textarea',
                'default' => 'You will Pay Using Your Mobile Apps .',
            ],
            'webhook_secret' => [
                'title' => 'Webhook Secret Key',
                'type' => 'text',
                'default' => '9e365899-3a23-4ee1-bd66-6dd2c7178078',
            ]
        ];
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        $webhook_url = home_url('/') . "?wc_upi_webhook=1&secret={$this->webhook_secret}&";

        $payload = [
            "key"               => "{$this->webhook_secret}",
            "client_txn_id"     => (string) $order_id,
            "amount"            => number_format($order->get_total(), 2, '.', ''),
            "p_info"            => "Order #$order_id",
            "customer_name"     => $order->get_formatted_billing_full_name(),
            "customer_email"    => $order->get_billing_email(),
            "customer_mobile"   => substr(preg_replace('/\D/', '', $order->get_billing_phone()), -10),
            "redirect_url"      => $webhook_url,
        ];

        $response = wp_remote_post('https://api.ekqr.in/api/create_order', [
            'method'  => 'POST',
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => json_encode($payload),
            'timeout' => 40,
        ]);

        if (is_wp_error($response)) {
            wc_add_notice('Payment error: ' . $response->get_error_message(), 'error');
            return;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!empty($body['data']['payment_url'])) {
            return [
                'result'   => 'success',
                'redirect' => esc_url_raw($body['data']['payment_url'])
            ];
        }

        if ($body['msg'] === "client_txn_id already exists") {
            if ($order->get_status() !== 'cancelled') {
                $order->update_status('cancelled', 'UPI payment failed or not completed.');
                $order->add_order_note('Order auto-cancelled due to UPI failure.');
            }

            wc_add_notice("Payment failed. Please try placing the order again.", 'error');

            return [
                'result'   => 'success',
                'redirect' => wc_get_checkout_url()
            ];
        }

        wc_add_notice("Payment initiation failed: " . ($body['data']['msg'] ?? 'Order Cancelled'), 'error');
        return;
    }
}



