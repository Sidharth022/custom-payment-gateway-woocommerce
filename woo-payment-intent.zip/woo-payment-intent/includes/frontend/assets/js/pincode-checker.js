jQuery(document).ready(function ($) {
function debounce(func, delay) {
    let timeout;
    return function (...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), delay);
    };
}

const fetchCityState = debounce(function () {
    const pincode = $('#billing_postcode').val().trim();
    if (pincode.length === 6) {
        $.ajax({
            url: pincode_ajax_object.ajax_url,
            type: 'POST',
            data: {
                action: 'get_city_state_by_pincode',
                pincode: pincode
            },
            beforeSend: function() {
                $('#billing_city').addClass('blurloader');
                $('#billing_address_2').addClass('blurloader');
                $('#billing_country_field .select2-selection--single').addClass('blurloader');
                $('#billing_state_field .select2-selection--single').addClass('blurloader');
            },
            success: function (response) {
                console.log(response);
                $('#billing_city').removeClass('blurloader');
                $('#billing_address_2').removeClass('blurloader');
                $('#billing_country_field .select2-selection--single').removeClass('blurloader');
                $('#billing_state_field .select2-selection--single').removeClass('blurloader');

                if (response.success) {
                    const areaname = response.data.name;
                    const city = response.data.city;
                    const stateName = response.data.state;
                    const country = response.data.country;
                    $('#billing_city').val(city);
                    $('#billing_address_2').val(areaname);
                    
                    $('#billing_country option').each(function () {
                        if ($(this).text().trim().toLowerCase() === country.trim().toLowerCase()) {
                            $('#billing_country').val($(this).val()).trigger('change');
                        }
                    });

                    setTimeout(() => {
                        $('#billing_state option').each(function () {
                            if ($(this).text().trim().toLowerCase() === stateName.trim().toLowerCase()) {
                                $('#billing_state').val($(this).val()).trigger('change');
                            }
                        });
                    }, 1000);
                }
            }
        });
    }
}, 600);

$('#billing_postcode').on('input', fetchCityState);
});