<?php
if (!defined('ABSPATH')) exit;

add_action('wp_loaded', function () {
    if (!isset($_GET['wc_upi_webhook'])) return;
    foreach ($_GET as $key => $value) {
        if (strpos($key, '?') === 0) {
            $_GET[ltrim($key, '?')] = $value;
            unset($_GET[$key]);
        }
    }

    $data = $_POST ?: $_GET;
    $order_id = absint($data['client_txn_id'] ?? 0);
    $secret = sanitize_text_field($data['secret'] ?? '');
    $txn_date = date('d-m-Y');

    $gateways = WC()->payment_gateways()->payment_gateways();
    $gateway = $gateways['custom_upi'] ?? null;

    if (!$gateway || $secret !== $gateway->webhook_secret) {
        http_response_code(403);
        exit('Unauthorized webhook request');
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        wp_send_json_error(['message' => 'Invalid order ID.'], 404);
    }

    $status_payload = [
        "key"            => "{$gateway->webhook_secret}",
        "client_txn_id"  => "$order_id",
        "txn_date"       => "$txn_date",
    ];

    $response = wp_remote_post('https://api.ekqr.in/api/check_order_status', [
        'method'  => 'POST',
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => json_encode($status_payload),
        'timeout' => 10,
    ]);

    $body = json_decode(wp_remote_retrieve_body($response), true);
    $status = $body['data']['status'] ?? 'failure';
    $utr = $body['data']['Merchant']['upi_id'] ?? '';

    if ($status === 'success') {
        update_post_meta($order_id, '_upi_utr', sanitize_text_field($utr));
        $order->payment_complete($utr);
        $order->add_order_note("UPI payment successful. UTR: $utr");
        wp_redirect($order->get_checkout_order_received_url());
        exit;
    }

    if ($order->get_status() !== 'cancelled') {
        $order->update_status('cancelled', 'UPI payment failed or not completed.');
        $order->add_order_note('Order auto-cancelled due to UPI failure.');
    }

    wc_add_notice('UPI payment failed. Please try again.', 'error');
    wp_redirect(wc_get_checkout_url());
    exit;
});
