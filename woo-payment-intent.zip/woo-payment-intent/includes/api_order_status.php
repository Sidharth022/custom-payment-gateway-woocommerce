<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Api_Order_Status {

    public static function plugin_activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woo_payment_api_order_status';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT,
            order_id BIGINT NOT NULL,
            order_status VARCHAR(255) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public static function plugin_uninstall() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woo_payment_api_order_status';
        $wpdb->query("DROP TABLE IF EXISTS $table_name");
    }

    public static function insert_data($order_id, $order_status ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woo_payment_api_order_status';

        $wpdb->insert($table_name, [
            'user_id'  => get_current_user_id(),
            'order_id'  => $order_id,
            'order_status'  => $order_status
        ]);
    }


    public static function getSpecific_data($order_id ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woo_payment_api_order_status';
        $user_id = get_current_user_id();
            $query = $wpdb->prepare("
            SELECT * FROM `$table_name`
            WHERE `order_id` = %d AND `user_id` = %d
        ", $order_id, $user_id);

         $results = $wpdb->get_results($query);

       return $results;
    }
}

// Activation trigger call
function woo_payment_plugin_activate() {
    Api_Order_Status::plugin_activate();
}
