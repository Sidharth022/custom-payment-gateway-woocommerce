<?php
if (!defined('ABSPATH')) exit;

class Woo_Payment_Intent_Init {

    public static function init() {
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if (!is_plugin_active('woocommerce/woocommerce.php')) {
            deactivate_plugins(plugin_basename(__FILE__));
            return;
        }

        require_once WOO_PAYMENT_INTENT_PATH . 'includes/class-wc-gateway-custom-upi.php';
        require_once WOO_PAYMENT_INTENT_PATH . 'includes/webhook-handler.php';

        add_filter('woocommerce_payment_gateways', [__CLASS__, 'add_gateway']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_scripts']);
        add_action('woocommerce_checkout_update_order_meta', [__CLASS__, 'save_utr']);
        add_action('woocommerce_admin_order_data_after_billing_address', [__CLASS__, 'display_utr_admin']);
        add_action('woocommerce_order_details_after_order_table', [__CLASS__, 'display_utr_customer']);
        add_filter('woocommerce_email_order_meta_fields', [__CLASS__, 'add_utr_to_email'], 10, 3);

        add_action('wp_ajax_get_city_state_by_pincode', [__CLASS__, 'fetch_city_state_by_pincode']);
        add_action('wp_ajax_nopriv_get_city_state_by_pincode', [__CLASS__, 'fetch_city_state_by_pincode']);
        add_filter('woocommerce_billing_fields', [__CLASS__,'customize_billing_phone_field']);


    }

    public static function add_gateway($gateways) {
        $gateways[] = 'WC_Gateway_Custom_UPI';
        // $gateways[] = 'WC_Gateway_Payment_Intent';
        return $gateways;
    }

    public static function enqueue_scripts() {
        wp_enqueue_style('woo-payment-frontend', WOO_PAYMENT_INTENT_URL . 'includes/frontend/assets/css/style.css');
        wp_enqueue_script('pincode-checker', WOO_PAYMENT_INTENT_URL. 'includes/frontend/assets/js/pincode-checker.js', ['jquery'], null, true);
        wp_localize_script('pincode-checker', 'pincode_ajax_object', [
            'ajax_url' => admin_url('admin-ajax.php'),
        ]);

    }

    public static function save_utr($order_id) {
        if (!empty($_POST['upi_utr'])) {
            update_post_meta($order_id, '_upi_utr', sanitize_text_field($_POST['upi_utr']));
        }
    }

    public static function display_utr_admin($order) {
        $utr = get_post_meta($order->get_id(), '_upi_utr', true);
        if ($utr) {
            echo '<p><strong>UPI UTR:</strong> ' . esc_html($utr) . '</p>';
        }
    }

    public static function display_utr_customer($order) {
        $utr = get_post_meta($order->get_id(), '_upi_utr', true);
        if ($utr) {
            echo '<p><strong>UPI UTR:</strong> ' . esc_html($utr) . '</p>';
        }
    }

    public static function add_utr_to_email($fields, $sent_to_admin, $order) {
        $utr = get_post_meta($order->get_id(), '_upi_utr', true);
        if ($utr) {
            $fields['upi_utr'] = [
                'label' => 'UPI UTR',
                'value' => $utr,
            ];
        }
        return $fields;
    }


    public static function fetch_city_state_by_pincode(){
        $pincode = sanitize_text_field($_POST['pincode'] ?? '');

        if (!$pincode || strlen($pincode) !== 6) {
            wp_send_json_error(['message' => 'Invalid PIN code.']);
        }

        $api_url = "https://api.postalpincode.in/pincode/$pincode";
        $response = wp_remote_get($api_url);
        
        if (is_wp_error($response)) {
            wp_send_json_error(['message' => 'API error.']);
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!empty($body[0]['PostOffice'][0])) {
            $name = $body[0]['PostOffice'][0]['Name'];
            $city  = $body[0]['PostOffice'][0]['District'];
            $state = $body[0]['PostOffice'][0]['State'];
            $country = $body[0]['PostOffice'][0]['Country'];

            wp_send_json_success([
                'name' => $name,
                'city' => $city,
                'state' => $state,
                'country' => $country,
            ]);
        } else {
            wp_send_json_error(['message' => 'No location found for this PIN code.']);
        }

    }

    /* Required Phone Number Field */
    public static function customize_billing_phone_field($fields) {
        $fields['billing_phone']['required'] = true; // Already default true
        $fields['billing_phone']['label'] = 'Phone (10 digits only)';
        return $fields;
    }
}
