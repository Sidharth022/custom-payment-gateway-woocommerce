<?php
/**
 * Plugin Name:       Woo Payment Intent
 * Plugin URI:        https://ezulix.com
 * Description:       Custom UPI payment integration with QR & webhook verification.
 * Version:           1.0.0
 * Author:            Ezulix
 * Author URI:        https://ezulix.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       woo-payment-intent
 * Domain Path:       /languages
 */
 
if (!defined('ABSPATH')) exit;

define('WOO_PAYMENT_INTENT_PATH', plugin_dir_path(__FILE__));
define('WOO_PAYMENT_INTENT_URL', plugin_dir_url(__FILE__));

if(!function_exists('woo_pr')){
    function woo_pr($data =  array()){
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}
require_once WOO_PAYMENT_INTENT_PATH . 'includes/class-woo-payment-init.php';

add_action('plugins_loaded', ['Woo_Payment_Intent_Init', 'init']);
